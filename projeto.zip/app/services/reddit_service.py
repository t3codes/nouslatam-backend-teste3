# services/reddit_service.py

import httpx
from typing import List, Dict, Optional

# URL base para a API autenticada do Reddit
BASE_URL = "https://oauth.reddit.com/r/{subreddit}/hot"

# --- Exceções Customizadas ---
class RedditAPIError(Exception ):
    """Exceção base para erros relacionados à API do Reddit."""
    def __init__(self, message: str, status_code: Optional[int] = None):
        self.status_code = status_code
        super().__init__(message)

class SubredditNotFound(RedditAPIError):
    """Lançada quando um subreddit não é encontrado."""
    def __init__(self, subreddit: str):
        message = f"O subreddit '{subreddit}' não foi encontrado ou é privado."
        super().__init__(message, status_code=404) # Usamos 404 para clareza interna

class RedditAuthenticationError(RedditAPIError):
    """Lançada para erros de autenticação (token inválido)."""
    def __init__(self):
        message = "Erro de autenticação. Verifique se o token de acesso é válido."
        super().__init__(message, status_code=401)

# --- Service ---
class RedditService:
    """
    Service para interagir com a API do Reddit e buscar posts populares.
    """
    @staticmethod
    async def fetch_posts(
        subreddit: str,
        token: str,
        period: str = "day",
        limit: int = 10
    ) -> List[Dict]:
        """
        Busca os posts mais populares (hot) de um determinado subreddit.

        Args:
            subreddit (str): O nome do subreddit (ex: 'python', 'django').
            token (str): O token de acesso OAuth2 para autenticação.
            period (str): O período de tempo para os posts ('hour', 'day', 'week', 'month', 'year', 'all').
            limit (int): O número máximo de posts a serem retornados.

        Returns:
            List[Dict]: Uma lista de dicionários, onde cada um representa um post.

        Raises:
            SubredditNotFound: Se o subreddit não for encontrado.
            RedditAuthenticationError: Se o token for inválido ou expirado.
            RedditAPIError: Para outros erros da API (rate limit, erros de servidor, etc.).
        """
        url = BASE_URL.format(subreddit=subreddit)
        
        params = {
            "t": period,
            "limit": limit,
            "raw_json": 1  # Evita que o Reddit escape caracteres HTML no JSON
        }

        # Cabeçalhos são cruciais para a API do Reddit
        headers = {
            # O User-Agent é OBRIGATÓRIO e deve ser único.
            # Formato: <plataforma>:<app_id>:<versao> (by /u/<seu_usuario>)
            "User-Agent": "MyCoolApp:v1.0.0 (by /u/seu_usuario_aqui)",
            "Authorization": f"Bearer {token}"
        }

        try:
            async with httpx.AsyncClient( ) as client:
                response = await client.get(url, params=params, headers=headers)

            # Verifica explicitamente por erros de autenticação
            if response.status_code == 401:
                raise RedditAuthenticationError()

            # Levanta uma exceção para outros erros HTTP (5xx, 429, etc.)
            response.raise_for_status()
            
            data = response.json()

            # A API do Reddit retorna uma listagem vazia para subreddits inexistentes
            # quando a consulta é bem-sucedida (status 200).
            if not data.get('data', {}).get('children'):
                 # Para ter certeza, podemos fazer uma verificação extra
                 is_real_subreddit = await RedditService.check_subreddit_exists(subreddit, token)
                 if not is_real_subreddit:
                    raise SubredditNotFound(subreddit)

            return data['data']['children']

        except httpx.HTTPStatusError as e:
            # Captura erros HTTP e os encapsula em nossa exceção customizada
            raise RedditAPIError(
                f"Erro na API do Reddit: {e.response.status_code} - {e.response.text}",
                status_code=e.response.status_code
             )
        except httpx.RequestError as e:
            # Captura erros de rede (conexão, timeout, etc. )
            raise RedditAPIError(f"Erro de conexão com o Reddit: {str(e)}")

    @staticmethod
    async def check_subreddit_exists(subreddit: str, token: str) -> bool:
        """
        Verifica se um subreddit existe usando um endpoint diferente.
        """
        url = f"https://oauth.reddit.com/r/{subreddit}/about"
        headers = {
            "User-Agent": "MyCoolApp:v1.0.0 (by /u/seu_usuario_aqui )",
            "Authorization": f"Bearer {token}"
        }
        try:
            async with httpx.AsyncClient( ) as client:
                response = await client.get(url, headers=headers)
            return response.status_code == 200
        except httpx.RequestError:
            return False

