from fastapi import FastAPI, Query, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from services.reddit_service import RedditService
from models.post_model import PostListResponse
from cache.cache_handler import CacheHandler
from fastapi.responses import JSONResponse
from typing import Optional
import httpx



app = FastAPI(
    title="API de Trending Topics",
    description="API para consulta de tópicos populares, com cache e filtros",
    version="1.0.0",
)

origins = [
    "http://localhost",  
    "http://localhost:3000",  
    "https://meuapp.com",  
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins, 
    allow_credentials=True,
    allow_methods=["*"], 
    allow_headers=["*"],  
)

@app.get("/", summary="Rota principal de teste")
async def root():
    return JSONResponse(content={"message": "Teste prático nouslatam backend"}, status_code=status.HTTP_200_OK)


@app.get("/posts/{subreddit}", response_model=PostListResponse)
async def get_posts(
    subreddit: str,
    period: Optional[str] = Query("all", enum=["hour", "day", "week", "month", "year", "all"]),
    limit: Optional[int] = 10
):
    cache_key = f"reddit_posts_{subreddit}_{period}_{limit}"
    
    # Verifica se os dados estão no cache
    cached_posts = CacheHandler.get_cache(cache_key)
    if cached_posts:
        return {"posts": cached_posts}

    # Se não estiver no cache, faz a requisição para a API do Reddit
    try:
        posts = await RedditService.fetch_posts(subreddit, period, limit)
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=f"Reddit API error: {e}")

    # Armazena os posts no cache para reutilização
    CacheHandler.set_cache(cache_key, posts)

    return {"posts": posts}